import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "../styles/AdminDashboard.css";

type Blog = {
  id: number;
  title: string;
  content: string;
  category: string;
  status: "draft" | "published";
};

const AdminDashboard = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const fetchBlogs = async () => {
    try {
      const res = await API.get("/blog/getall");
      if (res.data.success) {
        setBlogs(res.data.posts);
      } else {
        setError("Failed to load blogs");
      }
    } catch (err: any) {
      console.error('AdminDashboard fetchBlogs error:', err);
      console.log('Response status:', err.response?.status);
      if (err.response?.status === 401) {
        console.log('Redirecting to login...');
        navigate("/login");
      } else {
        setError(err.response?.data?.message || "Something went wrong");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  const handleDelete = async (id: number) => {
    try {
      await API.delete(`/blog/post/${id}`);
      fetchBlogs();
    } catch (err: any) {
      console.error(err);
      if (err.response?.status === 401) {
        navigate("/login");
      }
    }
  };

  const handleToggle = async (id: number) => {
    try {
      await API.put(`/blog/post/${id}/toggle`);
      fetchBlogs();
    } catch (err: any) {
      console.error(err);
      if (err.response?.status === 401) {
        navigate("/login");
      }
    }
  };

  return (
    <div className="dashboard">
      <h2 className="heading">Admin Dashboard</h2>

      {loading && <p>Loading blogs...</p>}
      {error && <p className="error">{error}</p>}

      <button
        className="create-btn"
        onClick={() => navigate("/create-blog")}
      >
        CREATE BLOG
      </button>

      {blogs.map((blog) => (
        <div key={blog.id} className="blog-card">
          <h3>{blog.title}</h3>
          <p>{blog.content}</p>
          <p>Category: {blog.category}</p>
          <p>Status: {blog.status}</p>

          <div className="btn-group">
            <button
              className="delete-btn"
              onClick={() => handleDelete(blog.id)}
            >
              Delete
            </button>

            <button
              className="toggle-btn"
              onClick={() => handleToggle(blog.id)}
            >
              Toggle
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AdminDashboard;